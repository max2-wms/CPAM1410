<?php
/**
*   Package: OnAir2
*   Description: Podcastfilter archive
*   Version: 0.0.0
*   Author: QantumThemes
*   Author URI: http://qantumthemes.com
**/
get_template_part('archive','podcast' ); ?>

