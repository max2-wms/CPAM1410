<?php
/**
*   Package: OnAir2
*   Description: Member category archive
*   Version: 0.0.0
*   Author: QantumThemes
*   Author URI: http://qantumthemes.com
**/
get_template_part('archive','members' ); 