<?php
/**
*   Package: OnAir2
*   Description: Video filters archive
*   Version: 0.0.0
*   Author: QantumThemes
*   Author URI: http://qantumthemes.com
**/
get_template_part('archive','qtvideo' ); ?>
