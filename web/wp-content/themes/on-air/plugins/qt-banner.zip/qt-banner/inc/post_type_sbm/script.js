// JavaScript Document
/*
	this is the module switch.
	Changes the active form fields dependently on the selected value in the module name


*/
jQuery(document).ready(function($)  
{  
	jQuery(document).ready(function() {
		if(jQuery('.datepicker')){
		    jQuery('.datepicker').datepicker({
		        dateFormat : 'dd-mm-yy'
		    });
		};
	});
	
});