/*
	// make the ajax call to count clicks
	// igor 29/04/2013

*/

jQuery(function($){
	$('a.superbanner').click(function(e){
		//e.preventDefault();
		var linkout = $(this).attr("data-linkout");
		var data = {
			action: 'my_action',
			postid: linkout
      	};
      	$.post(MyAjax.ajaxurl, data);
		//console.log(data);
		/*
    	
		*/
	});
});