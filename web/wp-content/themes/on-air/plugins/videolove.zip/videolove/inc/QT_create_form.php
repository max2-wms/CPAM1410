<?PHP

/*

____________________ CICLO PER LA GENERAZIONE DEI FORM E PER IL SALVATAGGIO ______________________
*/


$VDL_opt_form = '';

$error='';
foreach($VDL_varnames as $bv){			//1_salvataggio delle variabili // variables saving to db
		//echo '-> '. $bv[0].' - '.get_option($bv[0]).' - '.$_POST[$bv[0]].'<br />';
		
		if(isset($_POST[$bv[0]])){
			
			if(!update_option($bv[0],$_POST[$bv[0]])){
				$error.='<br />Error updating variable '.$bv;
			}
		}
		//2_generazione del form delle opzioni
		
		 
		 switch ($bv[2]){

		 	case 'section':
			  	$VDL_opt_form.='<div class="submatic-section" id="'.$bv[0].'"><h3><a class="submatic-tabtitle" href="#" data-section="'.$bv[0].'">'.$bv[1].'</a></h3>
			  	<div class="submatic-sectioncontent">'; 
			  	break;

			case 'sectionclose':
			  	$VDL_opt_form.='</div></div>'; 
				break;

		 	case 'color':
		 	 	$VDL_opt_form.='<p class="submatic-title"><strong>'.$bv[1].'</strong><br />';
			  	$VDL_opt_form.='<input type="color" size="100" name="'.$bv[0].'" value="'.get_option($bv[0]).'" />'; 
				break;

			case 'number':
			 	$VDL_opt_form.='<p class="submatic-title"><strong>'.$bv[1].'</strong><br />';
			  	$VDL_opt_form.='<input type="number"   name="'.$bv[0].'" value="'.get_option($bv[0]).'" min="'.$bv[3].'" max="'.$bv[4].'" />'; 
				break;

			case 'bol':
			 	$VDL_opt_form.='<p class="submatic-title"><strong>'.$bv[1].'</strong><br />';
				$VDL_opt_form.=' <input style="" type="radio" name="'.$bv[0].'" value="1" ';
				if(get_option($bv[0])=='1'){$VDL_opt_form.=' checked = "checked" ';}
				$VDL_opt_form.=' />  yes '; 
				
				$VDL_opt_form.='<input style="" type="radio" name="'.$bv[0].'" value="0" ';
				if(get_option($bv[0])=='0'){$VDL_opt_form.=' checked = "checked" ';}
				$VDL_opt_form.=' /> no </p>'; 
				break;
			
			case 'textarea':
			 	$VDL_opt_form.='<p class="submatic-title"><strong>'.$bv[1].'</strong><br />';
				$VDL_opt_form.='<textarea name="'.$bv[0].'" id="'.$bv[0].'" rows="10" cols="50" >'.get_option($bv[0]).'</textarea>'; 
				break;
			
			case 'static':
				break;
			default:
				$VDL_opt_form.='<p class="submatic-title"><strong>'.$bv[1].'</strong><br />';
			  	$VDL_opt_form.='<input type="text" size="100" name="'.$bv[0].'" value="'.get_option($bv[0]).'" />'; 
		 					
		 }	
		  
		  
		  
}
define ('VDL_FORM',  $VDL_opt_form);

?>