<?php

$fields=array(
		array('','section','','Podcast details'),
		array('_podcast_artist','text','','Artist Name'),
		array('_podcast_name','text','','Podcast Name'),
		array('_podcast_date','text','','Date'),
		array('_podcast_resourceurl','text','','Mixcloud, Soundcloud or MP3 url. Mp3 upload is disabled because most hostings does not allow huge file upload via http.')
		);

?>