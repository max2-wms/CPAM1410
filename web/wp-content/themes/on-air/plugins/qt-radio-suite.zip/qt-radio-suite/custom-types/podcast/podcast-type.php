<?php

add_action('init', 'podcast_register_type');  

function podcast_register_type() {
    $labelspodcast = array(
        'name' => esc_attr__("Podcast","qt-radio-suite"),
        'singular_name' => esc_attr__("Podcast","qt-radio-suite"),
        'add_new' => esc_attr__("Add new","qt-radio-suite"),
        'add_new_item' => esc_attr__("Add new podcast","qt-radio-suite"),
        'edit_item' => esc_attr__("Edit podcast","qt-radio-suite"),
        'new_item' => esc_attr__("New podcast","qt-radio-suite"),
        'all_items' => esc_attr__("All podcasts","qt-radio-suite"),
        'view_item' => esc_attr__("View podcast","qt-radio-suite"),
        'search_items' => esc_attr__("Search podcast","qt-radio-suite"),
        'not_found' => esc_attr__("No podcasts found","qt-radio-suite"),
        'not_found_in_trash' => esc_attr__("No podcasts found in trash","qt-radio-suite"),
        'menu_name' => esc_attr__("Podcasts","qt-radio-suite")

    );
    $args = array(
        'labels' => $labelspodcast,
        'public' => true,
        'publicly_queryable' => true,
        'show_ui' => true, 
        'show_in_menu' => true, 
        'query_var' => true,
        'rewrite' => true,
        'capability_type' => 'page',
        'has_archive' => true,
        'hierarchical' => false,
        'menu_position' => 40,
        'page-attributes' => true,
        'show_in_nav_menus' => true,
        'show_in_admin_bar' => true,
        'show_in_menu' => true,
         'menu_icon' => 'dashicons-megaphone',
        'supports' => array('title', 'thumbnail','editor' )
    ); 

    register_post_type( 'podcast' , $args );

    /* ============= create custom taxonomy for the podcasts ==========================*/

     $labels = array(
    'name' => esc_attr__( 'Podcast filters',"qt-radio-suite" ),
    'singular_name' => esc_attr__( 'Filter',"qt-radio-suite" ),
    'search_items' =>  esc_attr__( 'Search by filter',"qt-radio-suite" ),
    'popular_items' => esc_attr__( 'Popular filters',"qt-radio-suite" ),
    'all_items' => esc_attr__( 'All Podcasts',"qt-radio-suite" ),
    'parent_item' => null,
    'parent_item_colon' => null,
    'edit_item' => esc_attr__( 'Edit Filter',"qt-radio-suite" ), 
    'update_item' => esc_attr__( 'Update Filter',"qt-radio-suite" ),
    'add_new_item' => esc_attr__( 'Add New Filter',"qt-radio-suite" ),
    'new_item_name' => esc_attr__( 'New Filter Name',"qt-radio-suite" ),
    'separate_items_with_commas' => esc_attr__( 'Separate Filters with commas',"qt-radio-suite" ),
    'add_or_remove_items' => esc_attr__( 'Add or remove Filters',"qt-radio-suite" ),
    'choose_from_most_used' => esc_attr__( 'Choose from the most used Filters',"qt-radio-suite" ),
    'menu_name' => esc_attr__( 'Filters',"qt-radio-suite" ),
  ); 

  register_taxonomy('podcastfilter','podcast',array(
    'hierarchical' => false,
    'labels' => $labels,
    'show_ui' => true,
    'update_count_callback' => '_update_post_term_count',
    'query_var' => true,
    'rewrite' => array( 'slug' => 'podcastfilter' ),
  ));

}




$podcast_tab_custom = array(

    array(
        'label' => esc_attr__( 'Artist Name', "qt-radio-suite" ),
        'id'    => '_podcast_artist',
        'type'  => 'text'
        ),
    array(
        'label' => esc_attr__( 'Date', "qt-radio-suite" ),
        'id'    => '_podcast_date',
        'type'  => 'date'
        ),
    array(
        'label' => esc_attr__( 'Mixcloud, Soundcloud or MP3 url.', "qt-radio-suite" ),
        'id'    => '_podcast_resourceurl',
        'type'  => 'text'
        )
);
$podcast_tab_custom_box = new custom_add_meta_box( 'podcast_customtab', esc_attr__('Podcast details', "qt-radio-suite"), $podcast_tab_custom, 'podcast', true );
