<?php

define ('CUSTOM_TYPE_CHART','chart');
add_action('init', 'chart_register_type');  
function chart_register_type() {
	$labelschart = array(
		'name' => __("Charts","qt-radio-suite"),
		'singular_name' => __("Chart","qt-radio-suite"),
		'add_new' => 'Add new ',
		'add_new_item' => 'Add new '.__("chart","qt-radio-suite"),
		'edit_item' => 'Edit '.__("chart","qt-radio-suite"),
		'new_item' => 'New '.__("chart","qt-radio-suite"),
		'all_items' => 'All '.__("Charts","qt-radio-suite"),
		'view_item' => 'View '.__("chart","qt-radio-suite"),
		'search_items' => 'Search '.__("Charts","qt-radio-suite"),
		'not_found' =>  'No '.__("Charts","qt-radio-suite").' found',
		'not_found_in_trash' => 'No '.__("Charts","qt-radio-suite").' found in Trash', 
		'parent_item_colon' => '',
		'menu_name' =>__("Charts","qt-radio-suite")
	);
	$args = array(
		'labels' => $labelschart,
		'public' => true,
		'publicly_queryable' => true,
		'show_ui' => true, 
		'show_in_menu' => true, 
		'query_var' => true,
		'rewrite' => true,
		'capability_type' => 'page',
		'has_archive' => true,
		'hierarchical' => false,
		'menu_position' => null,
		'page-attributes' => true,
		'show_in_nav_menus' => true,
		'show_in_admin_bar' => true,
		'show_in_menu' => true,
		'menu_icon' => plugin_dir_url( __FILE__ ) . 'icon.png',
		'supports' => array('title', 'thumbnail','editor' )
	); 
    register_post_type( CUSTOM_TYPE_CHART , $args );

	/* ============= create custom taxonomy for the charts ==========================*/
	 $labels = array(
    'name' => __( 'Chart categories',"qt-radio-suite"),
    'singular_name' => __( 'Category',"qt-radio-suite"),
    'search_items' =>  __( 'Search by category',"qt-radio-suite" ),
    'popular_items' => __( 'Popular categorys',"qt-radio-suite" ),
    'all_items' => __( 'All charts',"qt-radio-suite" ),
    'parent_item' => null,
    'parent_item_colon' => null,
    'edit_item' => __( 'Edit category',"qt-radio-suite" ), 
    'update_item' => __( 'Update category',"qt-radio-suite" ),
    'add_new_item' => __( 'Add New category',"qt-radio-suite" ),
    'new_item_name' => __( 'New category Name',"qt-radio-suite" ),
    'separate_items_with_commas' => __( 'Separate categorys with commas',"qt-radio-suite" ),
    'add_or_remove_items' => __( 'Add or remove categorys',"qt-radio-suite" ),
    'choose_from_most_used' => __( 'Choose from the most used categorys',"qt-radio-suite" ),
    'menu_name' => __( 'categorys',"qt-radio-suite" ),
  ); 
  register_taxonomy('chartcategory','chart',array(
    'hierarchical' => false,
    'labels' => $labels,
    'show_ui' => true,
    'update_count_callback' => '_update_post_term_count',
    'query_var' => true,
    'rewrite' => array( 'slug' => 'chartcategory' ),
  ));
}



$fields_chart = array(
	array( // Repeatable & Sortable Text inputs
		'label'	=> 'Chart Tracks', // <label>
		'desc'	=> 'Add one for each track in the chart', // description
		'id'	=> 'track_repeatable', // field id and name
		'type'	=> 'repeatable', // type of field
		'sanitizer' => array( // array of sanitizers with matching kets to next array
			'featured' => 'meta_box_santitize_boolean',
			'title' => 'sanitize_text_field',
			'desc' => 'wp_kses_data'
		),
		
		'repeatable_fields' => array ( // array of fields to be repeated
			'releasetrack_track_title' => array(
				'label' => 'Title',
				'id' => 'releasetrack_track_title',
				'type' => 'text'
			)
			,'releasetrack_artist_name' => array(
				'label' => 'Artist/s',
				//'desc'	=> '(All artists separated by comma)', // description
				'id' => 'releasetrack_artist_name',
				'type' => 'text'
			)
			,'releasetrack_soundcloud_url' => array(
				'label' => 'Soundcloud, Youtube or MP3 Url',
				'desc'	=> 'Will be transformed into an embedded player in the chart page', // description
				'id' 	=> 'releasetrack_scurl',
				'type' 	=> 'text'
			)
			,'releasetrack_buy_url' => array(
				'label' => 'Track Buy link',
				'desc'	=> 'A link to buy the single track', // description
				'id' 	=> 'releasetrack_buyurl',
				'type' 	=> 'text'
			)
			,'releasetrack_img' => array(
				'label' => 'Cover',
				'desc'	=> 'Better 600x600', // description
				'id' => 'releasetrack_img',
				'type' => 'image'
			)
	
		)
	)
);





$tracks_box = new custom_add_meta_box( 'chart_tracks', 'Chart Tracks', $fields_chart, 'chart', true );



/*
*
*	get meta data ===========================================================================
*
*	======================================================================================
*/
if(!function_exists('qp_get_group')){
function qp_get_group( $group_name , $post_id = NULL ){
  	global $post; 	  
 	if(!$post_id){ $post_id = $post->ID; }
  	$post_meta_data = get_post_meta($post_id, $group_name, true);  
  	return $post_meta_data;
}}


/*
*
*	Chart shortcode
*
*/

if(!function_exists('qw_chart_shortcode')) {
	function qw_chart_shortcode($atts){
		extract( shortcode_atts( array(
			'id' => ""
		), $atts ) );

		
			?><h4><?php echo esc_attr(get_the_title($id)); ?></h4><?php
		    $events= qp_get_group('track_repeatable', $id);   
		    if(is_array($events)){
		        $pos = 1;
		        foreach($events as $event){ 
		            $neededEvents = array('releasetrack_track_title','releasetrack_scurl','releasetrack_buyurl','releasetrack_artist_name','releasetrack_img');
		            foreach($neededEvents as $n){
		                if(!array_key_exists($n,$events)){
		                    $events[$n] = '';
		                }
		            }
		           
		            ?>
		            

		            <div class="qw-chart-row grey lighten-4" id="chartItem<?php echo esc_attr($pos); ?>">
		                <div class="maincolor qw-chart-position"><?php echo esc_attr($pos); ?></div>

		               

		                 <?php 
		                if($event['releasetrack_buyurl'] != ''){
		                    ?>
		                    <a href="<?php echo esc_url($event['releasetrack_buyurl']); ?>" class="qw-chart-buy maincolor dark accentcolor-text tooltipped" data-position="left" data-tooltip="<?php echo esc_attr__("Go to shop","qt-radio-suite") ?>">
		                    <i class="mdi-action-add-shopping-cart"></i>
		                    </a>
		                    <?php
		                }   
		                ?>

		                <?php 
		                if($event['releasetrack_scurl'] != ''){
		                    ?>
		                    <a href="#" class="qw-chart-play accentcolor tooltipped" data-toggleclass="hidden" data-target="chartPlayer<?php echo esc_attr($pos); ?>" data-position="right" data-tooltip="<?php echo esc_attr__("Listen","qt-radio-suite") ?>">
		                    <i class="mdi-av-play-arrow"></i>
		                    </a>
		                    <?php
		                }   
		                ?>

		                 <?php 
		                if($event['releasetrack_img'] != ''){
		                    $img = wp_get_attachment_image_src($event['releasetrack_img'],'small');
		                    ?>
		                    <img src="<?php echo esc_url($img[0]); ?>" class="qw-chart-cover" alt="Cover">
		                    <?php
		                }   
		                ?>

		                <h4><?php echo esc_attr($event['releasetrack_track_title']); ?></h4>
		                <p><?php echo esc_attr($event['releasetrack_artist_name']); ?></p>
		                
		                <?php if($event['releasetrack_scurl'] != ''){ ?>
		                <div class="qw-music-player hidden" id="chartPlayer<?php echo esc_attr($pos); ?>">
		                    <?php  
		                    
		                        $regex_soundcloud = "/soundcloud.com/";                       
		                        $regex_mp3 = "/.mp3/";

		                        if(preg_match ( $regex_soundcloud , $event['releasetrack_scurl'] )){
		                            echo do_shortcode('[soundcloud params="auto_play=false&show_comments=true"  width="100%" url="'.esc_url($event['releasetrack_scurl']).'"]');
		                        } else if(preg_match ( $regex_mp3 , $event['releasetrack_scurl'] )) {
		                            echo do_shortcode('[audio src="'.esc_url($event['releasetrack_scurl']).'"]');
		                        }
		                    
		                    ?>
		                </div>
		                <?php } ?>
		            </div>

		            <?php 
		            $pos = $pos+1;
		    }//foreach
		}//end debuf if
		wp_reset_query();
	}
}

add_shortcode("embedchart","qw_chart_shortcode");


