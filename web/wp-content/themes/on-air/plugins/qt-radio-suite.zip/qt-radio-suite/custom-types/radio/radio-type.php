<?php

/* = custom post type release
===================================================*/



add_action('init', 'radiochannel_register_type');  


function radiochannel_register_type() {

   
	
	$labelsradio = array(
		'name' => esc_attr__("Radio channels","labelpro"),
		'singular_name' => esc_attr__("Radio channel","labelpro"),
		'add_new' => esc_attr__('Add new channel',"labelpro"),
		'add_new_item' => esc_attr__("Add new radio channel","labelpro"),
		'edit_item' => esc_attr__("Edit radio channel","labelpro"),
		'new_item' => esc_attr__("New radio channel","labelpro"),
		'all_items' => esc_attr__('All radio channels',"labelpro"),
		'view_item' => esc_attr__("View radio channel","labelpro"),
		'search_items' => esc_attr__("Search radio channels","labelpro"),
		'not_found' =>  esc_attr__("No radio channels found","labelpro"),
		'not_found_in_trash' => esc_attr__("No radio channels found in Trash","labelpro"), 
		'parent_item_colon' => '',
		'menu_name' => esc_attr__("Radio channels","labelpro")
	);
	$args = array(
		'labels' => $labelsradio,
		'public' => true,
		'publicly_queryable' => true,
		'show_ui' => true, 
		'show_in_menu' => true, 
		'query_var' => true,
		'rewrite' => true,
		'capability_type' => 'page',
		'has_archive' => true,
		'hierarchical' => false,
		'menu_position' => null,
		'page-attributes' => true,
		'show_in_nav_menus' => true,
		'show_in_admin_bar' => true,
		'show_in_menu' => true,
		'menu_icon' => plugin_dir_url( __FILE__ ) . 'icon.png',
		'supports' => array('title', 'thumbnail','editor', 'page-attributes' )
	); 
    register_post_type( 'radiochannel' , $args );



	

}




/* = Fields
===================================================*/




			
$radio_details = array(
	
	array(
		'label' => 'MP3 Stream URL',		
		'id'    => 'mp3_stream_url',
		'type'  => 'text'
		)
);

$radiochannel_details_box = new custom_add_meta_box( 'radio_details', 'Radio channel details', $radio_details, 'radiochannel', true );



