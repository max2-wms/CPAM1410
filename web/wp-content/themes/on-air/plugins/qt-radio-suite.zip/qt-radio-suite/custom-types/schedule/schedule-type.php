<?php

add_action('init', 'schedule_register_type');  
function schedule_register_type() {
	$labelsschedule = array(
		'name' => "Schedule",
		'singular_name' => "Schedule",
		'add_new' => 'Add New ',
		'add_new_item' => 'Add New Schedule',
		'edit_item' => 'Edit Schedule',
		'new_item' => 'New Schedule',
		'all_items' => 'All Schedule',
		'view_item' => 'View Schedule',
		'search_items' => 'Search Schedule',
		'not_found' =>  'No Schedule found',
		'not_found_in_trash' => 'No Schedule found in Trash', 
		'parent_item_colon' => '',
		'menu_name' => 'Schedule'
	);
	$args = array(
		'labels' => $labelsschedule,
		'public' => true,
		'publicly_queryable' => true,
		'show_ui' => true, 
		'show_in_menu' => true, 
		'query_var' => true,
		'rewrite' => true,
		'capability_type' => 'page',
		'has_archive' => true,
		'hierarchical' => false,
		'menu_position' => null,
		'page-attributes' => true,
		'show_in_nav_menus' => true,
		'show_in_admin_bar' => true,
		'show_in_menu' => true,
		'menu_icon' =>  plugin_dir_url( __FILE__ ) . 'icon.png',
		'supports' => array('title','page-attributes')
	); 
    register_post_type( "schedule" , $args );
}

/*
*
*	Meta boxes ===========================================================================
*
*	======================================================================================
*/

$fields = array(
    array(
		'label' => 'Happens only on a specific day (optional)',
		'description' => 'Used to identify the current show',
		'id'    => 'specific_day',
		'type'  => 'date'
		),
    array(
		'label' => 'Day of the week (Recursive)',
		'description' => 'Used to identify the current show',
		'id'    => 'week_day',
		'type'  => 'checkbox_group',
		'options' => array( 
		                   array('label'=> esc_attr__("Monday","qt-radio-suite"), 'value' => 'mon'),
		                   array('label'=> esc_attr__("Tuesday","qt-radio-suite"), 'value' => 'tue'),
		                   array('label'=> esc_attr__("Wednesday","qt-radio-suite"), 'value' => 'wed'),
		                   array('label'=> esc_attr__("Thursday","qt-radio-suite"), 'value' => 'thu'),
		                   array('label'=> esc_attr__("Friday","qt-radio-suite"), 'value' => 'fri'),
		                   array('label'=> esc_attr__("Saturday","qt-radio-suite"), 'value' => 'sat'),
		                   array('label'=> esc_attr__("Sunday","qt-radio-suite"), 'value' => 'sun')
		                   )
		),
	array( // Repeatable & Sortable Text inputs
		'label'	=> 'Shows', // <label>
		'desc'	=> 'Add here the shows', // description
		'id'	=> 'track_repeatable', // field id and name
		'type'	=> 'repeatable', // type of field
		'sanitizer' => array( // array of sanitizers with matching kets to next array
			'featured' => 'meta_box_santitize_boolean',
			'title' => 'sanitize_text_field',
			'desc' => 'wp_kses_data'
		),
		'repeatable_fields' => array ( // array of fields to be repeated
			'show_id' => array(
				'label' => 'Show',
				'id' => 'show_id',
				'posttype' => 'shows',
				'type' => 'post_chosen'
			),
			'show_time' => array(
				'label' => 'Time (HH:MM)',
				'id' => 'show_time',
				'type' => 'time'
			)
			,'show_end' => array(
				'label' => 'Time End (HH:MM)',
				'id' => 'show_time_end',
				'type' => 'time'
			)
		)
	)
);

$sample_box = new custom_add_meta_box( 'schedule_shows', 'Schedule shows', $fields, 'schedule', true );




