<?php

add_action('init', 'show_register_type');  
function show_register_type() {
	$labelsshow = array(
		'name' => "Shows",
		'singular_name' => "Show",
		'add_new' => 'Add New ',
		'add_new_item' => 'Add New Show',
		'edit_item' => 'Edit Show',
		'new_item' => 'New Show',
		'all_items' => 'All Shows',
		'view_item' => 'View Show',
		'search_items' => 'Search Show',
		'not_found' =>  'No Show found',
		'not_found_in_trash' => 'No Shows found in Trash', 
		'parent_item_colon' => '',
		'menu_name' => 'Shows'
	);
	$args = array(
		'labels' => $labelsshow,
		'public' => true,
		'publicly_queryable' => true,
		'show_ui' => true, 
		'show_in_menu' => true, 
		'query_var' => true,
		'rewrite' => true,
		'capability_type' => 'page',
		'has_archive' => true,
		'hierarchical' => false,
		'menu_position' => null,
		'page-attributes' => true,
		'show_in_nav_menus' => true,
		'show_in_admin_bar' => true,
		'show_in_menu' => true,
		'menu_icon' =>  plugin_dir_url( __FILE__ ) . 'icon.png',
		'supports' => array('title', 'thumbnail','editor', 'excerpt', 'comments', 'revisions'  )
	); 
    register_post_type( "shows" , $args );

	/* ============= create custom taxonomy for the shows ==========================*/
	$labels = array(
	    'name' => __( 'Genres',"qt-radio-suite" ),
	    'singular_name' => __( 'Genre',"qt-radio-suite" ),
	    'search_items' =>  __( 'Search by genre',"qt-radio-suite" ),
	    'popular_items' => __( 'Popular genres',"qt-radio-suite" ),
	    'all_items' => __( 'All shows',"qt-radio-suite" ),
	    'parent_item' => null,
	    'parent_item_colon' => null,
	    'edit_item' => __( 'Edit genre',"qt-radio-suite" ), 
	    'update_item' => __( 'Update genre',"qt-radio-suite" ),
	    'add_new_item' => __( 'Add New genre',"qt-radio-suite" ),
	    'new_item_name' => __( 'New genre Name',"qt-radio-suite" ),
	    'separate_items_with_commas' => __( 'Separate genres with commas',"qt-radio-suite" ),
	    'add_or_remove_items' => __( 'Add or remove genres',"qt-radio-suite" ),
	    'choose_from_most_used' => __( 'Choose from the most used genres',"qt-radio-suite" ),
	    'menu_name' => __( 'genres',"qt-radio-suite" )
  	); 
	register_taxonomy('genre','shows',array(
	    'hierarchical' => false,
	    'labels' => $labels,
	    'show_ui' => true,
	    'update_count_callback' => '_update_post_term_count',
	    'query_var' => true,
	    'rewrite' => array( 'slug' => 'genre' ),
	));
}

/*
*
*	Meta boxes ===========================================================================
*
*	======================================================================================
*/

$fields = array(
   array(
		'label' => 'Subtitle',
		'description' => 'Used in parallax header',
		'id'    => 'subtitle',
		'type'  => 'text'
		)
   	, array(
		'label' => 'Subtitle 2',
		'description' => 'Used in the parallax header',
		'id'    => 'subtitle2',
		'type'  => 'text'
		)
   	, array(
		'label' => 'Parallax header',
		'id'    => 'parallaxheader',
		'type'  => 'image'
		)
    , array(
		'label' => 'Short show description',
		'description' => 'Used in the schedule',
		'id'    => 'show_incipit',
		'type'  => 'editor'
		)
   	
);

$sample_box = new custom_add_meta_box( 'shows_meta', 'Show details', $fields, 'shows', true );





$fields2 = array(
	array(
	'label' => 'Facebook',
	'id'    => 'facebook',
	'type'  => 'text'
	),
	array(
	'label' => 'Flickr',
	'id'    => 'flickr',
	'type'  => 'text'
	),
	array(
	'label' => 'Google+',
	'id'    => 'googleplus',
	'type'  => 'text'
	),
	array(
	'label' => 'Itunes',
	'id'    => 'itunes',
	'type'  => 'text'
	),
	array(
	'label' => 'LastFM',
	'id'    => 'lastfm',
	'type'  => 'text'
	),
	array(
	'label' => 'Linkedin',
	'id'    => 'linkedin',
	'type'  => 'text'
	),
	array(
	'label' => 'Mixcloud',
	'id'    => 'mixcloud',
	'type'  => 'text'
	),
	array(
	'label' => 'Pinterest',
	'id'    => 'pinterest',
	'type'  => 'text'
	),

	array(
	'label' => 'Soundcloud',
	'id'    => 'soundcloud',
	'type'  => 'text'
	),
	array(
	'label' => 'Soundcloud',
	'id'    => 'soundcloud',
	'type'  => 'text'
	),
	array(
	'label' => 'Twitter',
	'id'    => 'twitter',
	'type'  => 'text'
	),

	array(
	'label' => 'Youtube',
	'id'    => 'youtube',
	'type'  => 'text'
	)

);

$sample_box2 = new custom_add_meta_box( 'shows_social', 'Social network pages', $fields2, 'shows', true );
