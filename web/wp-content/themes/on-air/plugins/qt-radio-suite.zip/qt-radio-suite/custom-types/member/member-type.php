<?php

add_action('init', 'member_register_type');  
function member_register_type() {
	$labelsmember = array(
		'name' => "Team Members",
		'singular_name' => "Team member",
		'add_new' => 'Add new team member',
		'add_new_item' => 'Add new team member',
		'edit_item' => 'Edit member',
		'new_item' => 'New member',
		'all_items' => 'All team members',
		'view_item' => 'View team member',
		'search_items' => 'Search team member',
		'not_found' =>  'No member found',
		'not_found_in_trash' => 'No members found in Trash', 
		'parent_item_colon' => '',
		'menu_name' => 'Team members'
	);
	$args = array(
		'labels' => $labelsmember,
		'public' => true,
		'publicly_queryable' => true,
		'member_ui' => true, 
		'member_in_menu' => true, 
		'query_var' => true,
		'rewrite' => true,
		'capability_type' => 'page',
		'has_archive' => true,
		'hierarchical' => false,
		'page-attributes' => true,
		'member_in_nav_menus' => true,
		'member_in_admin_bar' => true,
		'member_in_menu' => true,
		'menu_icon' =>  plugin_dir_url( __FILE__ ) . 'icon.png',
		'supports' => array('title', 'thumbnail','page-attributes','editor', 'revisions'  )
	); 
    register_post_type( "members" , $args );

	/* ============= create custom taxonomy for the members ==========================*/
	$labels = array(
	    'name' => __( 'Types',"qt-radio-suite" ),
	    'singular_name' => __( 'Type',"qt-radio-suite" ),
	    'search_items' =>  __( 'Search by Type',"qt-radio-suite" ),
	    'popular_items' => __( 'Popular Types',"qt-radio-suite" ),
	    'all_items' => __( 'All members',"qt-radio-suite" ),
	    'parent_item' => null,
	    'parent_item_colon' => null,
	    'edit_item' => __( 'Edit Type',"qt-radio-suite" ), 
	    'update_item' => __( 'Update Type',"qt-radio-suite" ),
	    'add_new_item' => __( 'Add New Type',"qt-radio-suite" ),
	    'new_item_name' => __( 'New Type Name',"qt-radio-suite" ),
	    'separate_items_with_commas' => __( 'Separate Types with commas',"qt-radio-suite" ),
	    'add_or_remove_items' => __( 'Add or remove Types',"qt-radio-suite" ),
	    'choose_from_most_used' => __( 'Choose from the most used Types',"qt-radio-suite" ),
	    'menu_name' => __( 'Member types',"qt-radio-suite" )
  	); 
	register_taxonomy('membertype','members',array(
	    'hierarchical' => false,
	    'labels' => $labels,
	    'member_ui' => true,
	    'update_count_callback' => '_update_post_term_count',
	    'query_var' => true,
	    'rewrite' => array( 'slug' => 'membertype' )
	));
}

/*
*
*	Meta boxes ===========================================================================
*
*	======================================================================================
*/

$fields = array(
	array(
		'label' => 'Short bio',
		'id'    => 'member_incipit',
		'type'  => 'editor'
		)
	, array(
		'label' => 'Parallax header (Suggested 1600x700)',
		'id'    => 'parallaxheader',
		'type'  => 'image'
		)
	,array(
		'label' => 'Role in the company',
		'id'    => 'member_role',
		'type'  => 'text'
		)
   	,array(
		'label' => 'Facebook link',
		'id'    => 'QT_facebook',
		'type'  => 'text'
		)
   	,array(
		'label' => 'Twitter link',
		'id'    => 'QT_twitter',
		'type'  => 'text'
		)
   	,array(
		'label' => 'Pinterest link',
		'id'    => 'QT_pinterest',
		'type'  => 'text'
		)
   	,array(
		'label' => 'Vimeo link',
		'id'    => 'QT_vimeo',
		'type'  => 'text'
		)
   	,array(
		'label' => 'Wordpress link',
		'id'    => 'QT_wordpress',
		'type'  => 'text'
		)
   	,array(
		'label' => 'Youtube link',
		'id'    => 'QT_youtube',
		'type'  => 'text'
		)
   	,array(
		'label' => 'Soundcloud link',
		'id'    => 'QT_soundcloud',
		'type'  => 'text'
		)
   	,array(
		'label' => 'Myspace link',
		'id'    => 'QT_myspace',
		'type'  => 'text'
		)
   	,array(
		'label' => 'Itunes link',
		'id'    => 'QT_itunes',
		'type'  => 'text'
		)
   	,array(
		'label' => 'Mixcloud link',
		'id'    => 'QT_mixcloud',
		'type'  => 'text'
		)
   	,array(
		'label' => 'Resident Advisor link',
		'id'    => 'QT_resident-advisor',
		'type'  => 'text'
		)
   	,array(
		'label' => 'ReverbNation link',
		'id'    => 'QT_reverbnation',
		'type'  => 'text'
		)

    
   	
);

$sample_box = new custom_add_meta_box( 'members_meta', 'member details', $fields, 'members', true );
