<?php
/*
*
*	QantumThemes Radio Suite
*	Shortcodes Functions
*
*/


/*
*
*	Shows tab shortcode
*
*/

if(!function_exists('qw_radiosuite_tab')) {
	function qw_radiosuite_tab($atts){
		extract( shortcode_atts( array(
			'schedule' => "0",
			'class' => ""
		), $atts ) );
		wp_reset_postdata();
		wp_reset_query();
		ob_start();
		include 'showgrid.php';
		wp_reset_postdata();
		wp_reset_query();
		return ob_get_clean();
	}

}
add_shortcode("showgrid","qw_radiosuite_tab");



/*
*
*	Slideshow shortcode
*
*/

if(!function_exists('qw_radiosuite_slide')) {
	function qw_radiosuite_slide($atts){
		extract( shortcode_atts( array(
			'quantity' => "5"
		), $atts ) );
		ob_start();
		include 'showslide.php';
		return ob_get_clean();
	}
}

add_shortcode("showslider","qw_radiosuite_slide");