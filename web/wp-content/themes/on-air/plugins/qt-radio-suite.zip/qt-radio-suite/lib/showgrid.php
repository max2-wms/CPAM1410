<?php


/*
*
*
*	Identify current date and day
*
*/

$date = current_time("Y-m-d");
//echo $date;

$current_dayweek = current_time("D");
//echo $dayweek;


/* How the comparison is made:

1. id the current day is like a specific day of the schedule, that one is the current. 

2. if no schedule has exact full date like today, we check if one has the day of the week of today

3. Else, we give up


*/

?>
<?php
if(!function_exists('qp_get_group')){
function qp_get_group( $group_name , $post_id = NULL ){
  	global $post; 	  
 	if(!$post_id){ $post_id = $post->ID; }
  	$post_meta_data = get_post_meta($post_id, $group_name, true);  
  	return $post_meta_data;
}}
?>
<div class="tabs-selector qw-pushpin hide-on-med-and-down">
      <ul class="tabs z-depth-1" id="qwShowSelector">
        <?php
			wp_reset_postdata();
			$args           = array(

				'post_type' => 'schedule',
				 'posts_per_page' => 31,
				 'post_status' => 'publish',
		 		 'orderby' => 'menu_order',
		 		 'order'   => 'ASC'
			);
			$the_query_meta = new WP_Query( $args );
			global $post;
			$total = 0;
			$tabsArray = array();
			$id_of_currentday = 0;

			while ( $the_query_meta->have_posts() ):

				$active = '';
				$maincolor = '';
				$the_query_meta->the_post();
				$total++;
				setup_postdata( $post );
				$tabsArray[] = array('name' => $post->post_name,
				                     'title' => $post->post_title,
				                     'id' => $post->ID);
				$schedule_date = get_post_meta($post->ID, 'specific_day', true);
				$schedule_week_day = get_post_meta($post->ID, 'week_day', true);


				/*
				1. check if is a precide date
				*/
				if($schedule_date == $date){
					$id_of_currentday = $post->ID;
					$active = ' active';
					$maincolor = ' maincolor';
				} else {
					/*
					2. check if is this day of the week
					*/
					if(is_array($schedule_week_day)){
						foreach($schedule_week_day as $day){ // each schedule can fit multiple days
							if(strtolower($day) == strtolower($current_dayweek)){
								$id_of_currentday = $post->ID;
								$active = ' active';
								$maincolor = ' maincolor';
							}
							
						}
					}

				}
				?>
				 <li class="tab col qwFlexwidth "><a href="#<?php echo esc_js(esc_attr($post->post_name)); ?>" id="optionSchedule<?php echo esc_js(esc_attr($post->post_name)); ?>" class="<?php echo esc_attr($active.$maincolor);/**/ ?>"><?php echo esc_attr($post->post_title); ?></a></li>

				 <?php
			endwhile;

			wp_reset_postdata();	
        ?>
      </ul>

   
</div>


<?php
	if($total > 0){
		echo '<div data-target=".qwFlexwidth" data-dynamicwidth="'.esc_js(esc_attr(100/$total)).'"></div>';
}
?>


<?php


/*
*
*	For mobile // options select instead of tabs // driven by js to click on hidden tabs
*
**

*/
?>
<div class="paper qw-padded z-depth-1 hide-on-large-only ">

	<h4><?php echo esc_attr__("Choose a day","qt-radio-suite"); ?></h4>
	<select id="qwShowDropdown">
	        <?php
				wp_reset_postdata();
				$result         = '';
				$args           = array(

					'post_type' => 'schedule',
					 'posts_per_page' => 31,
					 'post_status' => 'publish',
			 		 'orderby' => 'menu_order',
			 		 'order'   => 'ASC'
				);
				$the_query_meta = new WP_Query( $args );
				global $post;
				$total = 0;
				$tabsArray = array();
				//$id_of_currentday = 0;

				while ( $the_query_meta->have_posts() ):

					$active = '';
					$maincolor = '';
					$the_query_meta->the_post();
					$total++;
					setup_postdata( $post );
					$tabsArray[] = array('name' => $post->post_name,
					                     'title' => $post->post_title,
					                     'id' => $post->ID);
					?>
					 <option value="optionSchedule<?php echo esc_js(esc_attr($post->post_name)); ?>"><?php echo esc_attr($post->post_title); ?></option>
					 <?php
				endwhile;
				
				wp_reset_postdata();
	        ?>
	 </select>
</div>


<?php
/*
*	======================================================================
*
*	CONTENT OF THE TABS
*
*
*/
?>







<?php 

/*
*
*
*	For each tab
*
*/

$gridlayout = get_theme_mod("QT_schedule_default_layout","grid");




foreach($tabsArray as $tab){ 



?>

<div id="<?php echo esc_js(esc_attr($tab['name'])); ?>">



   <div class="cbp-vm-switcher cbp-vm-view-<?php echo $gridlayout; ?>">
   	<div class="cbp-header-title">
   		<h2 class="<?php if($id_of_currentday == $tab['id']){ ?> maincolor-text <?php } ?> z-depth-1 paper qw-padded"><?php echo esc_attr($tab['title']); ?></h2>
	</div>

	<div class="cbp-vm-options">
		<a href="#" class="cbp-vm-grid <?php if($gridlayout == 'grid'){ ?>active<?php } ?>"><i class="mdi-action-view-module"></i></a>
		<a href="#" class="cbp-vm-list <?php if($gridlayout == 'list'){ ?>active<?php } ?>"><i class="mdi-action-view-list"></i></a>
	</div>
	<ul class="cbp-vm-listcontainer">



		<?php
	   	$events= qp_get_group('track_repeatable',$tab['id']);   
	    if(is_array($events)){
	    	$n = 0;
	    	$count = 0;
	      	foreach($events as $event){ 
	      		if(array_key_exists('show_id', $event)){
	      			if(array_key_exists(0, $event['show_id'])){
	      				if(is_numeric($event['show_id'][0])){

	      					/*
	      					*
	      					*	Element
	      					*
	      					*/

	      					$count = $count+1;

					      	$neededEvents = array('show_id','show_time','show_time_end');
					      	foreach($neededEvents as $n){
					          if(!array_key_exists($n,$events)){
					              $events[$n] = '';
					          }
					      	}
					      	$show_id = $event['show_id'][0];
					      	global $post;
					      	$post = get_post($show_id); 
					      	$show_time = $event['show_time'];
					      	$show_time_end = $event['show_time_end'];




					      	$show_time_d = $show_time;
					      	$show_time_end_d = $show_time_end;


					      	// 12 hours format
					      	if(get_theme_mod('QT_timing_settings', '12') == '12'){
					      		$show_time_d = date("g:i a", strtotime($show_time_d));
					      		$show_time_end_d = date("g:i a", strtotime($show_time_end_d));
					      	}
					      	


					      	$now = current_time("H:i");
					        ?>
					          <li class="cpb-cardcont <?php if($now > $show_time && $now < $show_time_end && $id_of_currentday == $tab['id']){ ?>  cbp-vm-nowonair <?php } else { ?> cbp-vm-offair  <?php } ?> <?php if(($count%3 == 0) && $count > 1) { ?> cpb-nomargin-right <?php } ?>" >
						         <div class="card <?php if($now > $show_time && $now < $show_time_end && $id_of_currentday == $tab['id']){ ?>  maincolor <?php } ?>">
						          	<?php
						          	if(has_post_thumbnail($post->ID)){
						          		$attr = array(
											'class' => "img-responsive",
											'alt'   => trim( esc_attr($tab['title'])),
										);
										?><a class="cbp-vm-image" href="<?php echo esc_url(esc_attr(get_permalink($post->ID))); ?>" title="<?php echo esc_attr__("Read More about ","qt-radio-suite").esc_attr($post->post_title); ?>"><?php
						          		the_post_thumbnail( 'schedule-thumb', $attr );
						          		?></a><?php
								    }
						          	?>



						          	<h3 class="cbp-vm-title <?php if($now > $show_time && $now < $show_time_end && $id_of_currentday == $tab['id']){ ?>  accentcolor <?php } else { ?> maincolor  <?php } ?>">
						          		<?php echo esc_attr($post->post_title); ?>
						          	</h3>
						          	<div class="cbp-vm-time dark <?php if($now > $show_time && $now < $show_time_end && $id_of_currentday == $tab['id']){ ?>  accentcolor <?php } else { ?> maincolor  <?php } ?>"><span><i class="mdi-image-timer"></i> <?php echo esc_attr($show_time_d);?></span> <span><i class="mdi-image-timer-off"></i> <?php echo esc_attr($show_time_end_d);?></span></div>



						       
									<div class="cbp-vm-details">
										<?php
										$custom_desc = get_post_meta($post->ID, 'show_incipit', true);
										if($custom_desc == ''){
											$excerpt = $post->post_content;
											$custom_desc = $excerpt;
											$charlength = 160;
											if ( mb_strlen( $excerpt ) > $charlength ) {
												$subex = mb_substr( $excerpt, 0, $charlength - 5 );
												$exwords = explode( ' ', $subex );
												$excut = - ( mb_strlen( $exwords[ count( $exwords ) - 1 ] ) );
												if ( $excut < 0 ) {
													$custom_desc = mb_substr( $subex, 0, $excut );
												} else {
													$custom_desc = $subex;
												}
												
											} else {
												$custom_desc = $excerpt;
											}
											$custom_desc .= '[...]';
										}
										echo wp_kses_post($custom_desc);
										?>
									</div>

									<a class="cbp-vm-icon cbp-vm-add accentcolor" href="<?php echo esc_url(esc_attr(get_permalink($post->ID))); ?>"><span class=""><?php echo esc_attr__("Read","qt-radio-suite"); ?></span></a>
						          	
						          </div>
					          	

					          </li>
							<?php


						}	      				
					}

					
				wp_reset_postdata();
				}
			}//foreach
		} else {
			echo esc_attr__("Sorry, there are no shows scheduled on this day","qt-radio-suite");
		}
		?>


	</ul>
</div>



	



	   </div>
   <?php }  ?>
<div class="canc" id="qwShowgridEnd"></div>








    