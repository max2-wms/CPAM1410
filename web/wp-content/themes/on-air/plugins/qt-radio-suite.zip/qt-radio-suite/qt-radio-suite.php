<?php
/*
Plugin Name: QT RadioSuite
Plugin URI: http://www.qantumthemes.com/
Description: Enable the schedule functions for your online radio
Author: QantumThemes
Version: 1.0.7
Text Domain: qt-radio-suite
Domain Path: /languages
*/



function qtradio_load_plugin_textdomain() {
  load_plugin_textdomain( 'qt-radio-suite', FALSE, basename( dirname( __FILE__ ) ) . '/languages' );
}

add_action( 'plugins_loaded', 'qtradio_load_plugin_textdomain' );





require	plugin_dir_path( __FILE__ ) . '/metaboxes/meta_box.php';
require plugin_dir_path( __FILE__ ) . '/custom-types/shows/shows-type.php';
require plugin_dir_path( __FILE__ ) . '/custom-types/schedule/schedule-type.php';
require plugin_dir_path( __FILE__ ) . '/custom-types/chart/chart-type.php';
require plugin_dir_path( __FILE__ ) . '/custom-types/member/member-type.php';
require plugin_dir_path( __FILE__ ) . '/custom-types/radio/radio-type.php';
require plugin_dir_path( __FILE__ ) . '/custom-types/podcast/podcast-type.php';


/*
*	Libraries
*	=============================================================
*/

require_once( plugin_dir_path( __FILE__ ) . 'lib/widget-onair.php');
require_once( plugin_dir_path( __FILE__ ) . 'lib/widget-upcoming.php');
require_once( plugin_dir_path( __FILE__ ) . 'lib/widget-chart.php');
require_once( plugin_dir_path( __FILE__ ) . 'lib/widget-podcast.php');
require_once( plugin_dir_path( __FILE__ ) . 'lib/shortcodes.php');


/*
*
*	Page Meta boxes ======================================================================
*
*	======================================================================================
*/

$pageShortcode = array(
   array(
		'label' => 'Enable Automatic Show Slider',
		'desc' => 'Add automatic slider of shows in header, out of the container',
		'id'    => 'qw_headerslideshow',
		'type'  => 'checkbox'
		)
   	,   array(
		'label' => 'Enable Show Schedule',
		'desc' => 'Add schedule to the page, out of the container',
		'id'    => 'qw_headerschedule',
		'type'  => 'checkbox'
		)

   	,   array(
		'label' => 'Hide header title of the page',
		'desc' => 'For templates where the header title is separated',
		'id'    => 'qw_hidetitle',
		'type'  => 'checkbox'
		)
   	, array(
		'label' => 'News Category',
		'desc' => 'In a blog template, filter news by category',
		'id'    => 'qw_news_cat',
		'type'  => 'category'
		)
);

$sample_box_page = new custom_add_meta_box( 'header_shortcode', 'Page extras', $pageShortcode, 'page', true );


/*
*
*	Parallax Header ===========================================================================
*
*	======================================================================================
*/

$fieldsPage = array(
	 array(
		'label' => 'Enable Parallax Header',
		'desc' => 'Check this to enable the parallax header for some extra coolness',
		'id'    => 'qw_add_parallax_header',
		'type'  => 'checkbox'
		)
  	,array(
		'label' => 'Parallax header image',
		'id'    => 'qw_add_parallax_header_image',
		'type'  => 'image'
		)
    , array(
		'label' => 'Parallax Header content',
		'desc' => 'Content for the parallax header. Accepts HTML.',
		'id'    => 'qw_parallax_header_content',
		'type'  => 'editor'
		)




    
   	
);

$sample_box = new custom_add_meta_box( 'page_header_meta', 'Page header', $fieldsPage, 'page', true );




/*
*	Scripts and styles Frontend
*	=============================================================
*/

function qt_radiosuite_loader(){
	wp_enqueue_script( 'qtRadioSuiteScript',plugins_url( '/assets/script.js' , __FILE__ ), $deps = array("jquery"), $ver = false, $in_footer = true );
	wp_enqueue_style( 'qtRadioSuiteStyle',plugins_url( '/assets/style.css' , __FILE__ ),false);
}
add_action("wp_enqueue_scripts",'qt_radiosuite_loader', 99);


/*
*	Scripts and styles Backend
*	=============================================================
*/

function qt_radiosuite_loader_backend(){
	wp_enqueue_script( 'qtRadioSuiteMainAdmin',plugins_url( '/assets/main.admin.js' , __FILE__ ), $deps = array("jquery"), $ver = false, $in_footer = true );
}
add_action("admin_enqueue_scripts",'qt_radiosuite_loader_backend');




